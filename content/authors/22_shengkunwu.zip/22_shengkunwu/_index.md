---
name: Shengkun Wu

superuser: true

role: Since 2022


# website_url:   # 可以配置个人主页, 如果有的话,如github.io

user_groups:
- Undergraduate Students
---
Shengkun Wu is a third-year undergraduate student at School of Electrical Engineering, Tongling University. Now he has a keen interest in image segmentation.